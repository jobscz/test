package com.mark.previewexcelsimple.helper;

import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Base64;
import com.mark.previewexcelsimple.App;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Base64Helper {


    public static String excelToBase64(Uri uri) throws Throwable {
        if (uri == null) {
            throw new NullPointerException("excelToBase64 uri == null");
        }
        ParcelFileDescriptor descriptor = App.getInstance().getContentResolver().openFileDescriptor(uri, "r");
        FileInputStream fileInputStream = new FileInputStream(descriptor.getFileDescriptor());
        return excelToBase64(fileInputStream);
    }

    public static String excelToBase64(String excelFilePath) throws Throwable {
        if (excelFilePath == null) {
            throw new NullPointerException("excelToBase64 excelFilePath == null");
        }
        if (excelFilePath.endsWith(".xlsx")) {
            throw new RuntimeException("excelToBase64 not xlsx file");
        }
        File excelFile = new File(excelFilePath);
        FileInputStream fileInputStream = new FileInputStream(excelFile);
        return excelToBase64(fileInputStream);
    }

    public static String excelToBase64(InputStream inputStream) throws Throwable {
        if (inputStream == null) {
            throw new NullPointerException("excelToBase64 inputStream == null");
        }
        byte[] b = new byte[inputStream.available()];
        inputStream.read(b);
        return Base64.encodeToString(b, Base64.DEFAULT);
    }
}
