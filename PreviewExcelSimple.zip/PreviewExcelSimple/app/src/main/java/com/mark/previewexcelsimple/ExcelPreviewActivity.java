package com.mark.previewexcelsimple;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.mark.previewexcelsimple.cons.Const;
import com.mark.previewexcelsimple.helper.Base64Helper;
import com.mark.previewexcelsimple.helper.PermissionHelper;

import java.io.InputStream;

public class ExcelPreviewActivity extends AppCompatActivity {

    private static final String TAG = "ExcelPreviewActivity";

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excel_preview);
        webView = findViewById(R.id.web_view);
        configWebView();
    }

    private void previewExcel(String excelBase64String) {
        webView.loadUrl("javascript:loadExcelBase64('" + excelBase64String + "')");
    }

    private void configWebView() {
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        webView.getSettings().setDisplayZoomControls(true);

        webView.loadUrl(Const.EXCEL_PREVIEW_HTML_ASSETS_PATH);

        webView.setWebViewClient(new DefaultWebViewClient());
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bt_load1:
                try {
                    InputStream open = getAssets().open("test.xlsx");
                    String base64 = Base64Helper.excelToBase64(open);
                    Log.e("excel", "data " + base64);
                    previewExcel(base64);
                } catch (Throwable throwable) {
                    Log.e("excel", "t " + throwable.getMessage());
                }
                break;

            case R.id.bt_open_file_chooser:
                openFileChooser(view);
                break;

            case R.id.bt_load2:
                previewExcel(Const.TEST_01_EXCEL_BASE_64_STRING);
                break;
        }
    }


    private void openFileChooser(View view) {
        if (PermissionHelper.checkPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            realOpenFileChooser();
        } else {
            PermissionHelper.requestPermissions(this, 2,
                    Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
    }

    private void realOpenFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        startActivityForResult(intent, 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            realOpenFileChooser();
        }else {
            Toast.makeText(this, "读取和存储权限被拒，无法使用", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                Log.e(TAG, "data " + uri);
                try {
                    String base64 = Base64Helper.excelToBase64(uri);
                    previewExcel(base64);
                } catch (Throwable throwable) {
                    Log.e(TAG, "t " + throwable.getMessage());
                }

            }
        }
    }

    private class DefaultWebViewClient extends WebViewClient {
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            previewExcel(Const.TEST_01_EXCEL_BASE_64_STRING);
        }
    }
}